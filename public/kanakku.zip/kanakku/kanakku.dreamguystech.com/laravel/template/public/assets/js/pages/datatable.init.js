/*
Author       : Dreamguys
Template Name: Kanakku - Bootstrap Admin Template
Version      : 1.0
*/

    // Datatable
    if ($('#datatable').length > 0) {
        $('#datatable').DataTable({
            "bFilter": false,
        });
    }
 